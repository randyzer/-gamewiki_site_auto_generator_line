# Changelog

## Unreleased — V2.7 Candidate / WS-01

- Migrate the unchanged 41-row/16-column Registry into one SOP-owned canonical Contract.
- Add evidence workflow/outcome identity and honest history/conflict methods.
- Separate deterministic REF fixtures and real PROJECT adoption; update precise package/Prompt references.
- Candidate acceptance is recorded separately; no Starter behavior, runtime dependency or release change.

## 2.6.5

Lifecycle-state corrective patch based on the released and frozen `GAME_SOP_v2.6.4`
source at tag `GAME_SOP_v2.6.4`, commit
`b8c6f0ef7545635ec57bc3809b233b0945ce1918`, tree
`a24ddd5218c1269db257927bfcc202515d94647f`, and annotated tag object
`4a74ae78e5e9a567b3da5f964a4ab3b6012a7a98`. The methodology authority defined by this
version is `docs/NEW_GAME_SITE_SOP_v2.6.5.md`. Release status is determined by the
repository's authoritative Git refs and annotated release tag, not by lifecycle prose in this
document.

### Corrected

- Removed mutable current release-lifecycle claims from active normative documentation.
- Advanced package and authority identity to V2.6.5 without changing methodology.

### Preserved

- All V2.6.4 architecture, methodology, hard/soft semantics, feature history, and non-goals.

## 2.6.4

Documentation-correction release based on the released and frozen `GAME_SOP_v2.6.3`
source. V2.6.4 was released as tag `GAME_SOP_v2.6.4` at commit
`b8c6f0ef7545635ec57bc3809b233b0945ce1918`, tree
`a24ddd5218c1269db257927bfcc202515d94647f`, and annotated tag object
`4a74ae78e5e9a567b3da5f964a4ab3b6012a7a98`. Its methodology authority at release was
`docs/NEW_GAME_SITE_SOP_v2.6.4.md`.

### Corrected

- Corrected current package and authority identity from outdated V2.6.3 status wording to
  the V2.6.4 documentation-correction patch line.
- Recorded V2.6.3 as the released and frozen source baseline without changing methodology.

### Preserved

- All V2.6.3 architecture, methodology, hard/soft semantics, feature history, and non-goals.

## 2.6.3

Bounded SOP implementation based on frozen `GAME_SOP_v2.6.2` provenance. Its methodology
authority at release was `docs/NEW_GAME_SITE_SOP_v2.6.3.md`. V2.6.3 was released and frozen as
`GAME_SOP_v2.6.3` at commit `e72a54114edd336fe88d43af444fe2dae72edff8`.

### Added

- Provider-neutral separation of provider configuration/bootstrap from semantic placement responsibility.
- Stable semantic-anchor and qualitative homepage primary-ad guidance without pixel or screen-depth rules.
- Hard zero-output behavior for disabled/unconfigured placements and provider-contract-based multiple-slot/key safety.
- Known-dimension responsive reservation and layered ad-adjacent layout diagnostics.
- Separate `requested`, `rendered`, and `viewable` evidence meanings.
- `PROVIDER/ENVIRONMENT CHECK REQUIRED` and `HUMAN_BROWSER_CHECK_REQUIRED` review classifications.
- A conditional Human Ads Review checklist inside existing Human Visual/Release evidence, including desktop/mobile and locale-semantic review.
- Public/private provider configuration boundary and concise SEO/UX non-regression principles.

### Preserved

- All unrelated V2.6.2 methodology, including Runtime Page Inventory, media lifecycle, evidence build, Pagefind, source/reviewer capability distinctions, Human Visual ownership, release workflow, and Stable Core / Flexible Edge.
- Provider registry, orchestration/plugin frameworks, analytics/backend/dashboard/database, A/B or automatic optimization, automatic provider switching, bid/account/API management, provider-specific frameworks, page-type policy engine, ad DSL, numeric placement thresholds, mandatory second slot, new ads lifecycle states, and runtime observability API remain non-goals.

### Packaging

- Renamed the sole current SOP authority from `docs/NEW_GAME_SITE_SOP_v2.6.2.md` to `docs/NEW_GAME_SITE_SOP_v2.6.3.md`; V2.6.2 history remains available through Git.
- Updated existing README, manifest, execution, QA, Human evidence, and onboarding conventions without adding a governance entrypoint or archive duplicate.

## 2.6.2

Narrow SOP contract release based on frozen `GAME_SOP_v2.6.1` provenance.
The current methodology authority is
`docs/NEW_GAME_SITE_SOP_v2.6.2.md`.

### Added

- Pagefind artifact classes and Starter-owned normalization responsibility.
- An 800,000 B ceiling for normalized contract-required Pagefind payload;
  raw Pagefind-directory size remains diagnostic.
- Fail-closed required-artifact and unknown-structure rules, while known
  optional stock UI already absent remains valid.
- The official non-final `npm run build:evidence` lifecycle, explicit evidence
  marker semantics, Human review hard stop, and canonical final closure.

### Preserved

- Human ownership of Visual `PASS` and final fail-closed readiness.
- The V2.6.1 Stable Core and all stated V2.6.2 non-goals, including deferred
  D7.

### Packaging

- Renamed the current SOP authority to `docs/NEW_GAME_SITE_SOP_v2.6.2.md`;
  prior SOP content remains available through Git history.
- Archived the V2.6.1 implementation report under `archive/v2.6.1/`.

## 2.6.1

Packaging and SOP hardening release based on frozen `GAME_SOP_v2.6`
provenance. The current V2.6.1 methodology authority is explicitly named
`docs/NEW_GAME_SITE_SOP_v2.6.1.md`.

### Added

- D1 media contract compatibility and deterministic readiness mapping.
- D2 public/internal source boundary.
- D3 runtime evidence contract.
- D4 targeted re-review closure.
- D5 public workflow-language QA.
- D6 production-origin preflight.

### Deferred

- D7 remains deferred.

### Packaging

- Archived the historical V2.6 implementation report under `archive/v2.6/`.
- Archived `archive/v2.6/V2.6_CHANGE_PROPOSAL_V0.2.md` as historical
  baseline/provenance, not current authority.

## 2.6

Production-hardening release based on frozen `GAME_SOP_v2.5` provenance and the approved `V2.6_CHANGE_PROPOSAL_V0.2.md`.

### Added

- Verification Transport Resilience Policy: evidence validity is separate from preferred transport availability.
- Reviewer Capability Preflight before evidence-dependent independent/C2C review.
- First-class Game Recognition Gate in Human Visual Review.
- Official Visual Evidence priority order and planning fields.
- Strongest-competitor visual/media benchmark requirement.
- Complete media lifecycle states for need, candidate, rights/risk, human decision, integration, and visual gate.
- Positive `NO MEDIA NEEDED` definition.
- Third-party media failure-state quality expectation.
- Site chrome vs page content media clarification.
- V2.6 implementation report artifact.

### Changed

- README, SOP, execution prompt, templates, QA checklist, status template, source policy, SEO spec, and patch maintenance now enforce v2.6 evidence/review/visual-media hardening.
- `MEDIA_DECISION_TABLE` now tracks media lifecycle outside the Runtime Page Inventory.
- Human Visual Review now separately records Technical Visual QA, Game Recognition, Visual Identity, Media Density, Semantic Media Matching, Responsive Visual, and Media Failure State.

### Preserved

- GAME_SOP_v2.5 source/provenance discipline.
- KISS, YAGNI, 80/20, High Cohesion, Low Coupling, Modular, Adaptable, Stable Core / Flexible Edge.
- single runtime Page Inventory SSOT.
- Competitive Coverage, Partial Page, Minimum Wiki Coverage, and Navigation Coverage gates.
- no media quotas.
- intentional no-media path.
- no automated legal/copyright/licensing engine.
- no media DAM/CMS/database or generic transport/reviewer/media/visual DSL.
- explicit deployment approval and target verification.

## 2.5

Additive SOP upgrade based on the approved `SOP_V2.5_CHANGE_PROPOSAL.md`.

### Added

- Visual Identity Gate with evidence/status dimensions.
- First-Viewport Game Recognition Gate.
- Route-level `MEDIA_DECISION_TABLE` artifact for public P0 media decisions.
- Media Availability / Resolution Gate.
- Screenshot-backed Human Content / Visual Gate.
- Template Residue Audit.
- Visual Rhythm Gate.
- Whole-Page Visual Consistency Gate.
- Media Performance / Delivery Check.
- `HUMAN_VISUAL_REVIEW_EVIDENCE` artifact for representative rendered screenshots.

### Changed

- README, SOP, execution prompt, templates, QA checklist, status template, content template, source policy, SEO spec, and patch maintenance now enforce v2.5 visual/media release evidence.
- Site Structure keeps media planning at page-family level and points route-level decisions to the media decision table.
- Page Inventory template adds only an external-reference note; no media/layout fields were added.

### Preserved

- GAME_SOP_2.2 source/provenance discipline.
- single runtime Page Inventory SSOT.
- Competitive Coverage, Partial Page, Minimum Wiki Coverage, and Navigation Coverage gates.
- no media quotas.
- intentional no-media path.
- no automated legal engine.
- no universal media byte threshold, CDN, transcoding service, or performance framework.
- explicit deployment approval and target verification.

## 2.2

Production-learning release after the first real site built from the v2.1 workflow.

### Added

- Competitive Coverage Gate
- Competitive Coverage Matrix
- Minimum Wiki Coverage Rule
- Partial Page Rule
- Navigation Coverage Gate
- Media Richness Rule
- Visual Richness Rule
- Player-facing UX Rule
- Planning-to-Implementation Reconciliation
- Version Provenance for SOP / Starter / Master Prompt
- media/source provenance guidance
- stronger release blockers for thin navigation, text-only core pages, and research-metadata-heavy public UX

### Changed

- P0/P1/P2 classification no longer treats incomplete data as an automatic reason to suppress an entire useful page.
- Competitor analysis must produce a decision for each meaningful page family: `COVER_NOW`, `COVER_PARTIAL`, `DEFER`, or `NOT_RELEVANT`.
- Site Structure must include navigation discoverability and media planning.
- QA now evaluates competitive coverage, public information architecture, media richness, and player-facing UX.
- Visual Identity expanded from palette consistency to Visual Identity + Visual Richness.

### Preserved

- official/observed source hierarchy
- single runtime Page Inventory SSOT
- fact-layer discipline
- no fabricated meta/tier/build claims
- KISS/YAGNI/80-20
- explicit deployment approval and target verification
