# GAME_CODEX_MASTER_PROMPT V2.7 Candidate — WS-01

Current candidate entry: [CodexMasterPrompt_v2.7Candidate.md](CodexMasterPrompt_v2.7Candidate.md). Exact SOP Contract identity: [CONTRACT_REFERENCE.json](CONTRACT_REFERENCE.json); sole normative file is docs/COMMERCIAL_GAME_SITE_PRODUCT_CONTRACT_V2.7.md in the SOP artifact. This repository contains no Registry copy.

SourceBaselineCommit: `f655a0e08529060be8b716330ffcecf489a4484d`; sourceBaselineTree: `6adc7107c498459ed92696cb189cfc1ec9915258`. Candidate branch v2.7/normative-foundation inherits local V2.6.5 history. HEAD identifies the predecessor until a separately authorized commit; modified/new files require actual working-tree hashes.

Status: WS-01 candidate; independent acceptance is recorded separately; full V2.7 compatibility/release and Starter implementation are incomplete. The unchanged v2.6.5Final file and archive are historical context, not competing current entries. Original Phase 0–5, media/ads/final-evidence and Human responsibilities are preserved. Fixture regression and real adoption remain separate; implementation/test success never manufactures current product PASS.
